#include "Instructions.h"

Instructions::Instructions() {
    // Configuraci�n del texto de las instrucciones
    fuente.loadFromFile("FuenteRegular.ttf");
    instructionsText.setFont(fuente);
    instructionsText.setString("Instrucciones:\n- Usa las flechas izquierda y derecha para mover la barra.\n- Rebota la pelota contra la barra y las plataformas.\n- Evita que la pelota caiga fuera de la pantalla.\n-Presiona Espacio para comenzar a jugar.\n-Presiona ESC para volver al menu.");
    instructionsText.setCharacterSize(24);
    instructionsText.setFillColor(sf::Color::White);
    instructionsText.setPosition(100, 100); // Posici�n de las instrucciones en la pantalla

    // Configuraci�n del bot�n de "Volver"
    backButton.setFont(fuente);
    backButton.setString("Volver");
    backButton.setCharacterSize(24);
    backButton.setFillColor(sf::Color::Yellow);
    backButton.setPosition(100, 400); // Posici�n del bot�n de "Volver"
}

void Instructions::Draw(sf::RenderWindow& window) {
   // std::cout << "drawing instructions";
    window.draw(instructionsText);
    window.draw(backButton);
}

bool Instructions::HandleClick(sf::Vector2i mousePos) {
    if (backButton.getGlobalBounds().contains(static_cast<sf::Vector2f>(mousePos))) {
        return true; // Indica que se debe regresar al men�
    }
    return false;
}