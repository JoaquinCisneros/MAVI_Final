#include "Game.h"
#include <iostream>

Game::Game(int alto, int ancho, string titulo) {
	window = new RenderWindow(VideoMode(ancho, alto), titulo);
	window->setFramerateLimit(60);
	score = 0;

	gameText = new TextoJuego();

	//Sonidos
	bounceBuffer.loadFromFile("Bouncing.wav");
	bounceSound.setBuffer(bounceBuffer);
	bounceSound.setVolume(40.0f);
	//Musica
	music.openFromFile("BackgroundArcade.wav");
	music.setVolume(10.0f);
	//Game Over
	goBuffer.loadFromFile("GameOver.wav");
	goSound.setBuffer(goBuffer);
	goSound.setVolume(30.0f);
	//Flag de inicio
	flag = 0;
	clock.restart();
}

void Game::Play() {
	
	while (window->isOpen()) {
		Event evt;
		while (window->pollEvent(evt)) {
			ProcessEvent(evt);
		}
		DrawGame();
		if (CheckCollisions(*player1, *ball1)) {
			ball1->Bounce();
			bounceSound.play();
			score++;
			//Verificacion por consola de la escala de velocidad
			std::cout << ball1->getVelocity().y << " " << ball1->getVelocity().x;
		}
		UpdateGame();
	}
}
void Game::DrawGame() {
	window->clear();
	player1->drawPlayer(*window);
	ball1->drawBall(*window);
	gameText->Draw(*window);
	window->display();

}
void Game::ProcessEvent(Event& evt) {
	switch (evt.type)
	{
	case Event::Closed():
		window->close();
		break;
	case Event::KeyPressed:
		if (evt.key.code == Keyboard::Space) {

			if (flag == 0) {
				flag = 1;
				music.play();
				clock.restart();
			}
			break;
		}
	}
	//Movimiento derecha si no llega al borde
	if (Keyboard::isKeyPressed(Keyboard::Right)) {
		if (player1->getX() < 650) {
			player1->setX(player1->getX() + 15);
		}
	}
	//Movimiento izquierda si no llega al borde
	if (Keyboard::isKeyPressed(Keyboard::Left)) {
		if (player1->getX() > 0) {
			player1->setX(player1->getX() - 15);
		}
	}
}
void Game::UpdateGame() {
	ball1->Move(flag);
	int seconds = clock.getElapsedTime().asSeconds();
	gameText->SetTimerString("Tiempo: " + to_string(seconds));
	gameText->SetString("Rebotes: " + to_string(score));
	if (ball1->GameOver()) {
		//Reseteamos velocidad, frenamos la pelota y la colocamos en el medio
		goSound.play();
		clock.restart();
		flag = 0;
		score = 0;
		ball1->setVelocity(3.0f, 3.0f);
		ball1->SetPosition(window->getSize().x / 2, window->getSize().y / 2);
		music.stop();
	}
}
bool Game::CheckCollisions(const Player& player, const Ball& ball) {
	FloatRect playerBounds = player.player.getGlobalBounds();
	FloatRect ballBounds = ball.ball.getGlobalBounds();

	return playerBounds.intersects(ballBounds);
}