#include "Game.h"
#include <iostream>

Game::Game(int alto, int ancho, string titulo) {
	window = new RenderWindow(VideoMode(ancho, alto), titulo);
	window->setFramerateLimit(60);
	currentState = GameState::MENU;

	score = 0;

	menu = new Menu();
	instructions = new Instructions();
	gameText = new TextoJuego();
	build = new Build(ancho, alto);

	//Sonidos
	bounceBuffer.loadFromFile("Bouncing.wav");
	bounceSound.setBuffer(bounceBuffer);
	bounceSound.setVolume(40.0f);
	//Musica
	music.openFromFile("BackgroundArcade.wav");
	music.setVolume(10.0f);
	music.setLoop(true);
	//Game Over
	goBuffer.loadFromFile("GameOver.wav");
	goSound.setBuffer(goBuffer);
	goSound.setVolume(30.0f);
	//Flag de inicio
	flag = false;
	movingRight = false;
	movingLeft = false;
	clock.restart();
	speed = 400.0f;
}

void Game::Play() {

	while (window->isOpen()) {
		Event evt;
		while (window->pollEvent(evt)) {
			ProcessEvent(evt);
		}

		FloatRect ballBounds = ball1->ball.getGlobalBounds();
		if (CheckCollisions(*player1, *ball1)) {
			ball1->Bounce(1);
			bounceSound.play();
			score++;
			//Verificacion por consola de la escala de velocidad
			std::cout << ball1->getVelocity().y << " " << ball1->getVelocity().x;
		}
		if (build->plataforma1.getGlobalBounds().intersects(ballBounds)||
			build->plataforma2.getGlobalBounds().intersects(ballBounds)
			) {
			ball1->Bounce(1);
			bounceSound.play();
		}
		//Utilizo shapes delimitando en los extremos izquierdos y derecho, para evitar colisiones extra�as y simular el rebote en el eje X
		if (build->limiteIzq1.getGlobalBounds().intersects(ballBounds) ||
			build->limiteIzq2.getGlobalBounds().intersects(ballBounds) ||
			build->limiteDer1.getGlobalBounds().intersects(ballBounds) ||
			build->limiteDer2.getGlobalBounds().intersects(ballBounds) ||
			player1->limitLeft.getGlobalBounds().intersects(ballBounds) ||
			player1->limitRight.getGlobalBounds().intersects(ballBounds))
		{
			ball1->Bounce(0);
			bounceSound.play();
		}
		if (build->techo.getGlobalBounds().intersects(ballBounds)) {
			ball1->Bounce(1);
			bounceSound.play();
		}
		if (build->paredDer.getGlobalBounds().intersects(ballBounds) ||
			build->paredIzq.getGlobalBounds().intersects(ballBounds))
		{
			ball1->Bounce(0);
		}
		UpdateGame();
		DrawGame();
	}
}
void Game::DrawGame() {
	window->clear(Color::Black);

	if (currentState == GameState::MENU) {
		menu->Draw(*window);
	}
	else if (currentState == GameState::PLAYING) {
		build->Draw(*window);
		player1->drawPlayer(*window);
		ball1->drawBall(*window);
		gameText->Draw(*window);
	}
	else if (currentState == GameState::INSTRUCTIONS) {
		instructions->Draw(*window);
	}

	window->display();

}
void Game::ProcessEvent(Event& evt) {
	if (evt.type == Event::Closed) {
		window->close();
	}

	if (currentState == GameState::MENU) {
		if (evt.type == sf::Event::MouseButtonPressed && evt.mouseButton.button == sf::Mouse::Left) {
			currentState = menu->HandleClick(sf::Mouse::getPosition(*window));
		}
	}
	else if (currentState == GameState::PLAYING) {
		if (evt.type == Event::KeyPressed) {
			if (evt.key.code == Keyboard::Space) {
				if (flag == 0) {
					flag = 1;
					music.play();
					clock.restart();
				}
			}
			if (evt.key.code == Keyboard::Right) {
				movingRight = true;
			}
			if (evt.key.code == Keyboard::Left) {
				movingLeft = true;
			}
		}
		if (evt.type == Event::KeyReleased) {
			if (evt.key.code == Keyboard::Right) {
				movingRight = false;
			}
			if (evt.key.code == Keyboard::Left) {
				movingLeft = false;
			}
		}
	}
	else if (currentState == GameState::INSTRUCTIONS) {
		if (evt.type == sf::Event::MouseButtonPressed && evt.mouseButton.button == sf::Mouse::Left) {
			if (instructions->HandleClick(sf::Mouse::getPosition(*window))) {
				currentState = GameState::MENU;
			}
		}
		if (evt.type == sf::Event::KeyPressed && evt.key.code == sf::Keyboard::Escape) {
			currentState = GameState::MENU;
		}
	}
}

void Game::UpdateGame() {
	if (currentState == GameState::PLAYING) {
		float dt = dtClock.restart().asSeconds();
		ball1->Move(flag, dt);
		int seconds = clock.getElapsedTime().asSeconds();

		if (flag) {
			gameText->SetString(gameText->timer, "Tiempo: " + to_string(seconds));
			gameText->SetString(gameText->scoreText, "Rebotes: " + to_string(score));

			if (movingRight && player1->getX() < 650) {
				player1->setX(player1->getX() + speed * dt);
			}
			if (movingLeft && player1->getX() > 0) {
				player1->setX(player1->getX() - speed * dt);
			}
		}

		if (ball1->GameOver()) {
			goSound.play();
			clock.restart();
			flag = 0;
			score = 0;
			ball1->setVelocity(Vector2f(150.0f, 150.0f));
			ball1->SetPosition(window->getSize().x / 2, window->getSize().y / 2);
			music.stop();
		}
	}
}
bool Game::CheckCollisions(const Player& player, const Ball& ball) {
	FloatRect playerBounds = player.player.getGlobalBounds();
	FloatRect ballBounds = ball.ball.getGlobalBounds();

	return playerBounds.intersects(ballBounds);
}