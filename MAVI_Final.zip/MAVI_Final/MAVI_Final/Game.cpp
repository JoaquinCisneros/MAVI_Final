#include "Game.h"
#include <iostream>

Game::Game(int alto, int ancho, string titulo) {
	window = new RenderWindow(VideoMode(ancho, alto), titulo);
	window->setFramerateLimit(60);
	score = 0;
	font.loadFromFile("FuenteRegular.ttf");
	scoreText.setFont(font);
	scoreText.setFillColor(Color::White);
	scoreText.setCharacterSize(20);
	scoreText.setPosition(600, 570);
}

void Game::Play() {
	
	while (window->isOpen()) {
		Event evt;
		while (window->pollEvent(evt)) {
			ProcessEvent(evt);
		}
		DrawGame();
		if (CheckCollisions(*player1, *ball1)) {
			ball1->Bounce();
			score++;
			scoreText.setString("Puntuacion: " + to_string(score));
		}
		UpdateGame();
	}
}
void Game::DrawGame() {
	window->clear();
	player1->drawPlayer(*window);
	ball1->drawBall(*window);
	window->draw(scoreText);
	window->display();

}
void Game::ProcessEvent(Event& evt) {
	switch (evt.type)
	{
	case Event::Closed():
		window->close();
		break;
	}
	//Movimiento derecha si no llega al borde
	if (Keyboard::isKeyPressed(Keyboard::Right)) {
		if (player1->getX() < 650) {
			player1->setX(player1->getX() + 10);
		}
	}
	//Movimiento izquierda si no llega al borde
	if (Keyboard::isKeyPressed(Keyboard::Left)) {
		if (player1->getX() > 0) {
			player1->setX(player1->getX() - 10);
		}
	}
}
void Game::UpdateGame() {
	ball1->Move();
}
bool Game::CheckCollisions(const Player& player, const Ball& ball) {
	FloatRect playerBounds = player.player.getGlobalBounds();
	FloatRect ballBounds = ball.ball.getGlobalBounds();

	return playerBounds.intersects(ballBounds);
}