#include "TextoJuego.h"
TextoJuego::TextoJuego() {
	font.loadFromFile("FuenteRegular.ttf");
	scoreText.setFont(font);
	scoreText.setFillColor(Color::White);
	scoreText.setCharacterSize(20);
	scoreText.setPosition(600, 570);

	instructions.setFont(font);
	instructions.setFillColor(Color::White);
	instructions.setCharacterSize(15);
	instructions.setPosition(0, 0);
	instructions.setString("Presona ESPACIO para comenzar!\nHaz rebotar la pelota tantas veces como puedas!");

	timer.setFont(font);
	timer.setFillColor(Color::White);
	timer.setCharacterSize(15);
	timer.setPosition(400, 0);

}
void TextoJuego::Draw(RenderWindow& w) {
	w.draw(scoreText);
	w.draw(instructions);
	w.draw(timer);
}
void TextoJuego::SetString(string str) {
	scoreText.setString(str);
}
void TextoJuego::SetTimerString(string str) {
	timer.setString(str);
}
