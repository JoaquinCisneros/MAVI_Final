#include "TextoJuego.h"
TextoJuego::TextoJuego() {
	font.loadFromFile("FuenteRegular.ttf");
	scoreText.setFont(font);
	scoreText.setFillColor(Color::Black);
	scoreText.setCharacterSize(20);
	scoreText.setPosition(600, 570);

	highScoreText.setFont(font);
	highScoreText.setFillColor(Color::Black);
	highScoreText.setCharacterSize(25);
	highScoreText.setPosition(750, 25);

	timer.setFont(font);
	timer.setFillColor(Color::Black);
	timer.setCharacterSize(15);
	timer.setPosition(400, 10);

}
void TextoJuego::Draw(RenderWindow& w) {
	w.draw(scoreText);
	w.draw(timer);
	w.draw(highScoreText);
}
void TextoJuego::SetString(Text& textToChange, string str) { //objeto Text por referencia para reutilizar funciones
	textToChange.setString(str);
}
