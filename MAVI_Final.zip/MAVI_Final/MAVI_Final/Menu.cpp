#include "Menu.h"
Menu::Menu() {
    fuente.loadFromFile("FuenteRegular.ttf");
    playButton.setFont(fuente);
    playButton.setString("Play");
    playButton.setCharacterSize(24);
    playButton.setFillColor(sf::Color::White);
    playButton.setPosition(100, 100);  // Posici�n en la ventana

    instructionsButton.setFont(fuente);
    instructionsButton.setString("Instructions");
    instructionsButton.setCharacterSize(24);
    instructionsButton.setFillColor(sf::Color::White);
    instructionsButton.setPosition(100, 150);  // Posici�n en la ventana
}

void Menu::Draw(sf::RenderWindow& window) {
    //std::cout << "drawing menu";
    window.draw(playButton);
    window.draw(instructionsButton);
}

GameState Menu::HandleClick(sf::Vector2i mousePos) {
    if (playButton.getGlobalBounds().contains(static_cast<sf::Vector2f>(mousePos))) {
        return GameState::PLAYING;
    }
    if (instructionsButton.getGlobalBounds().contains(static_cast<sf::Vector2f>(mousePos))) {
        return GameState::INSTRUCTIONS;
    }
    return GameState::MENU;
}
