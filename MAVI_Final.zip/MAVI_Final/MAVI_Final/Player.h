#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

class Player {
private:
	friend class Game;
	Texture _playerT;
	Sprite _playerS;
	int x;
	int y;
public:
	RectangleShape player;
	RectangleShape limitLeft, limitRight;
	Player(float ancho, float alto, Color color);
	//Setters y getters, en caso de ser necesarios
	int getX();
	int getY();
	void setX(int newX);
	void setY(int newY);
	void drawPlayer(RenderWindow& wnd);
};
