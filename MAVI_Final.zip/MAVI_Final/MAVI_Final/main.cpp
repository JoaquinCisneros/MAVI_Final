#include <iostream>
#include "Game.h"
using namespace std;

int main() {

	Game game(600, 800, "Bounce it!");
	game.Play();

	return 0;
}