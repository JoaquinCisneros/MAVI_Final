#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/Audio.hpp>
#include "Player.h"
#include "Ball.h"
using namespace sf;
using namespace std;

class Game {

private:
	RenderWindow* window;
	Player* player1 = new Player(150.0, 30.0, Color::Blue);
	Ball* ball1 = new Ball(20.00, Color::Red, Vector2f(3.00, 3.00));

	Font font;
	Text scoreText;

	Music music;

	SoundBuffer bounceBuffer;
	Sound bounceSound;

	SoundBuffer goBuffer;
	Sound goSound;

	bool flag;

	int score;

public:
	//constructor
	Game(int alto, int ancho, string titulo);

	//loop
	void Play();
	void ProcessEvent(Event& evt);
	bool CheckCollisions(const Player& player, const Ball& ball);
	void DrawGame();
	void UpdateGame();

};


