#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <iostream>
class Instructions {
public:
    Instructions();
    void Draw(sf::RenderWindow& window);
    bool HandleClick(sf::Vector2i mousePos);
private:
    sf::Font fuente;
    sf::Text instructionsText;
    sf::Text backButton;
};

