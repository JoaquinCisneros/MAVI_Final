#pragma once
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include "GameState.h"
#include <iostream>
class Menu
{
public:
    Menu();
    void Draw(sf::RenderWindow& window);
    GameState HandleClick(sf::Vector2i mousePos);
private:
    sf::Font fuente;
    sf::Text playButton;
    sf::Text instructionsButton;
};

