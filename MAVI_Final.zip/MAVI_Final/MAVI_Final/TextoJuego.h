#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;
using namespace std;
#include <iostream>
class TextoJuego
{
private:
	Font font;

public:
	Text scoreText;
	Text highScoreText;
	Text instructions;
	Text timer;
	TextoJuego();
	void Draw(RenderWindow& w);
	void SetString(Text& textToChange, string str);
	//void SetTimerString(string str);
};

