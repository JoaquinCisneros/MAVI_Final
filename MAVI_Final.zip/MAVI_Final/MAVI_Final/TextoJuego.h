#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;
using namespace std;
#include <iostream>
class TextoJuego
{
private:
	Font font;

public:
	Text scoreText;
	Text highScoreText;
	Text timer;
	TextoJuego();
	void Draw(RenderWindow& w);
	void SetString(Text& textToChange, string str);
	Font& getFont() {
		return font;
	};
	//void SetTimerString(string str);
};

