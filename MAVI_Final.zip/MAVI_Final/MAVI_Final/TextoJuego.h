#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;
using namespace std;
#include <iostream>
class TextoJuego
{
private:
	Font font;

public:
	Text scoreText;
	Text instructions;
	Text timer;
	TextoJuego();
	void Draw(RenderWindow& w);
	void SetString(string str);
	void SetTimerString(string str);
};

