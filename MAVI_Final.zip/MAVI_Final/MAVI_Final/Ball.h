#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include "Build.h"
using namespace sf;
using namespace std;

class Ball {
private:
	int ballX;
	int ballY;
	Vector2f velocity;
	Vector2f acceleration;

public:
	CircleShape ball;
	Ball(float radius, Color, Vector2f acceleration0);
	void drawBall(RenderWindow& wnd);
	void Move(bool flag, float deltaTime);
	int getX();
	int getY();
	void SetPosition(int posX, int posY);
	void setVelocity(Vector2f asc);
	Vector2f getVelocity();
	void naturalBounce();
	void Bounce(bool axis);

	//Condicion de corte

	bool GameOver();
};
