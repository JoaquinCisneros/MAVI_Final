#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;
using namespace std;

class Ball {
private:
	int ballX;
	int ballY;
	Vector2f velocity;

public:
	CircleShape ball;
	Ball(float radius, Color, Vector2f velocity0);
	void drawBall(RenderWindow& wnd);
	void Move(bool flag);
	int getX();
	int getY();
	void SetPosition(int posX, int posY);
	void setVelocity(float velX, float velY);
	Vector2f getVelocity();
	void naturalBounce();
	void Bounce();

	//Condicion de corte

	bool GameOver();
};
