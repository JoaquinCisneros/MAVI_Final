#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;
using namespace std;

class Ball {
private:
	int ballX;
	int ballY;
	Vector2f velocity;

public:
	CircleShape ball;
	Ball(float radius, Color, Vector2f velocity0);
	void drawBall(RenderWindow& wnd);
	void Move();
	int getX();
	int getY();
	void setVelocity(int velX, int velY);
	void naturalBounce();
	void Bounce();
};
