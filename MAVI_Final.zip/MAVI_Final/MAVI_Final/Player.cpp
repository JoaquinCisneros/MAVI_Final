#include "Player.h"

Player::Player(float ancho, float alto, Color color) {

	x = 350;
	y = 570;

	player.setSize(Vector2f(ancho, alto));
	player.setFillColor(color);
	player.setPosition(getX(), getY());

	limitLeft.setSize(Vector2f(2, alto));
	limitLeft.setFillColor(Color::Magenta);
	limitLeft.setPosition(player.getPosition());

	limitRight.setSize(Vector2f(2, alto));
	limitRight.setFillColor(Color::Magenta);
	limitRight.setPosition(player.getPosition().x + player.getSize().x, player.getPosition().y);
}
int Player::getX() {
	return x;
}
int Player::getY() {
	return y;
}
void Player::setX(int newX) {
	x = newX;
}
void Player::setY(int newY) {
	y = newY;
}
void Player::drawPlayer(RenderWindow& wnd) {
	player.setPosition(getX(), getY());
	limitLeft.setPosition(player.getPosition());
	limitRight.setPosition(player.getPosition().x + player.getSize().x, player.getPosition().y);
	wnd.draw(player);
	wnd.draw(limitLeft);
	wnd.draw(limitRight);
}
