#include "Ball.h"
#include "Game.h"

Ball::Ball(float radius, Color color, Vector2f velocity0) {
	ballX = 400;
	ballY = 300;

	velocity = velocity0;

	ball.setRadius(radius);
	ball.setFillColor(color);
	ball.setPosition(getX(), getY());
}
int Ball::getX() {
	return ballX;
}
int Ball::getY() {
	return ballY;
}
void Ball::drawBall(RenderWindow& wnd) {
	wnd.draw(ball);
}
void Ball::setVelocity(int velX, int velY) {
	velocity.x = velX;
	velocity.y = velY;
}
void Ball::naturalBounce() {
	if (ball.getPosition().x + ball.getRadius() > 800 || ball.getPosition().x - ball.getRadius() < 0) {
		velocity.x = -velocity.x;
	}

	if (ball.getPosition().y + ball.getRadius() > 600 || ball.getPosition().y - ball.getRadius() < 0) {
		velocity.y = -velocity.y;
	}
}
void Ball::Move() {
	ball.move(velocity);
	naturalBounce();
}
void Ball::Bounce() {
	velocity.y = -velocity.y;
}