#include "Ball.h"
#include "Game.h"

Ball::Ball(float radius, Color color, Vector2f acceleraton0) {
	ballX = 400;
	ballY = 300;

	acceleration = acceleraton0;

	ball.setRadius(radius);
	ball.setOrigin(radius / 2, radius /2);
	ball.setFillColor(color);
	ball.setPosition(getX(), getY());
}
int Ball::getX() {
	return ballX;
}
int Ball::getY() {
	return ballY;
}
void Ball::SetPosition(int posX, int posY) {
	ball.setPosition(posX, posY);
}
void Ball::drawBall(RenderWindow& wnd) {
	wnd.draw(ball);
}
void Ball::setVelocity(Vector2f asc) {
	acceleration = asc; //para modificar la velocidad, modificamos la aceleracion
}
Vector2f Ball::getVelocity() {
	return velocity;
}
void Ball::naturalBounce() {
	if (ball.getPosition().x + ball.getRadius() > 780 || ball.getPosition().x - ball.getRadius() < 0) {
		//invertimos ambas para que sea un rebote sin simular gravedad
		velocity.x = -velocity.x;
		acceleration.x = -acceleration.x;
	}
	if (ball.getPosition().y - ball.getRadius() < 0) {
		//Dejamos que se vaya la pelota por abajo
		velocity.y = -velocity.y;
		acceleration.y = -acceleration.y;
	}
}
void Ball::Move(bool flag, float deltaTime) {
	if (flag) {

		velocity = acceleration * deltaTime;

		ball.move(velocity);

		naturalBounce();
	}
}
void Ball::Bounce(bool axis) {
	if (axis == 1) {
		velocity.y = -velocity.y;
		acceleration.y = -acceleration.y;
	}
	else if (axis == 0) {
		velocity.x = -velocity.x;
		acceleration.x = -acceleration.x;
	}

	if (velocity.x > 0) {
		acceleration.x += 30.0f;
	}
	if (velocity.x < 0) {
		acceleration.x -= 30.0f;
	}
	if (velocity.y > 0) {
		acceleration.y += 30.0f;
	}
	if (velocity.y < 0) {
		acceleration.y -= 30.0f;
	}

}

bool Ball::GameOver() {
	if (ball.getPosition().y + ball.getRadius() > 600) {
		return true;
	}
	else {
		return false;
	}
}