#include "Ball.h"
#include "Game.h"

Ball::Ball(float radius, Color color, Vector2f velocity0) {
	ballX = 400;
	ballY = 300;

	velocity = velocity0;

	ball.setRadius(radius);
	ball.setOrigin(radius / 2, radius /2);
	ball.setFillColor(color);
	ball.setPosition(getX(), getY());
}
int Ball::getX() {
	return ballX;
}
int Ball::getY() {
	return ballY;
}
void Ball::SetPosition(int posX, int posY) {
	ball.setPosition(posX, posY);
}
void Ball::drawBall(RenderWindow& wnd) {
	wnd.draw(ball);
}
void Ball::setVelocity(float velX, float velY) {
	velocity.x = velX;
	velocity.y = velY;
}
Vector2f Ball::getVelocity() {
	return velocity;
}
void Ball::naturalBounce() {
	if (ball.getPosition().x + ball.getRadius() > 800 || ball.getPosition().x - ball.getRadius() < 0) {
		velocity.x = -velocity.x;
	}

	if (ball.getPosition().y - ball.getRadius() < 0) {
		//Dejamos que se vaya la pelota por abajo
		velocity.y = -velocity.y;
	}
}
void Ball::Move(bool flag) {
	if (flag) {
		ball.move(velocity);
		naturalBounce();
	}
}
void Ball::Bounce() {
	velocity.y = -velocity.y;
	//Aumentar velocidad con el rebote, para aumentar dificultad con el tiempo
	if (velocity.x > 0) {
		velocity.x += 0.5f;
	}
	if (velocity.x < 0) {
		velocity.x -= 0.5f;
	}
	if (velocity.y > 0) {
		velocity.y += 0.5f;
	}
	if (velocity.y < 0) {
		velocity.y -= 0.5f;
	}
}
bool Ball::GameOver() {
	if (ball.getPosition().y + ball.getRadius() > 600) {
		return true;
	}
	else {
		return false;
	}
}