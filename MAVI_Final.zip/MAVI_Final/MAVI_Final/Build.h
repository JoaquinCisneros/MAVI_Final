#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;
class Build {
private:
	friend class Game;
	RectangleShape paredIzq, paredDer, techo,
		limiteIzq1, limiteIzq2, limiteDer1, limiteDer2;//Limites
	RectangleShape plataforma1, plataforma2; //Obstaculos
public:
	Build(int ancho, int alto) {
		paredIzq.setSize(Vector2f(10.0f, alto));
		paredIzq.setPosition(0, 0);
		paredIzq.setFillColor(Color::White);

		paredDer.setSize(Vector2f(10, alto));
		paredDer.setPosition(ancho - 10, 0);
		paredDer.setFillColor(Color::White);

		techo.setSize(Vector2f(ancho, 10));
		techo.setPosition(0, 0);
		techo.setFillColor(Color::White);

		plataforma1.setSize(Vector2f(ancho / 8, 20));
		plataforma1.setPosition(100, alto / 2);
		plataforma1.setFillColor(Color::Green);

		limiteIzq1.setSize(Vector2f(5.0f, 18));
		limiteIzq1.setPosition(plataforma1.getPosition().x - 1, plataforma1.getPosition().y + 1);
		limiteIzq1.setFillColor(Color::Magenta);

		limiteIzq2.setSize(Vector2f(5.0f, 18));
		limiteIzq2.setPosition(plataforma1.getPosition().x + plataforma1.getSize().x - 3, plataforma1.getPosition().y + 1);
		limiteIzq2.setFillColor(Color::Magenta);

		plataforma2.setSize(Vector2f(ancho / 8, 20));
		plataforma2.setPosition(600, alto / 2);
		plataforma2.setFillColor(Color::Green);

		limiteDer1.setSize(Vector2f(5.0f, 18));
		limiteDer1.setPosition(plataforma2.getPosition().x - 1, plataforma2.getPosition().y + 1);
		limiteDer1.setFillColor(Color::Magenta);

		limiteDer2.setSize(Vector2f(5.0f, 18));
		limiteDer2.setPosition(plataforma2.getPosition().x + plataforma2.getSize().x - 3, plataforma2.getPosition().y + 1);
		limiteDer2.setFillColor(Color::Magenta);

	};
	void Draw(RenderWindow& w) {
		w.draw(paredIzq);
		w.draw(paredDer);

		w.draw(techo);

		w.draw(plataforma1);
		w.draw(limiteIzq1);
		w.draw(limiteIzq2);

		w.draw(plataforma2);
		w.draw(limiteDer1);
		w.draw(limiteDer2);
	};
	FloatRect getBounds(int platNum) {
		if (platNum == 1) {
			return plataforma1.getGlobalBounds();
		}
		if (platNum == 2) {
			return plataforma2.getGlobalBounds();
		}
	}

};
