#pragma once
enum class GameState {
		MENU,
		PLAYING,
		INSTRUCTIONS
};
